function [ result ] = plotFunction( t, pointsX, pointsY, u, stepsize, o )
%plot plots curve
%   Detailed explanation goes here
    %creates arrays for the points
    resX = [];
    resY = [];
    
    %calculates points
    for i = u:stepsize:o
        res = eval(t, pointsX, pointsY, i);
        resX = [resX, res(1)];
        resY = [resY, res(2)];
    end

    plot(resX, resY);
    xlabel('x - Achse');
    ylabel('y - Achse');
    title('Beispielfunktion');

    result = 0;
end