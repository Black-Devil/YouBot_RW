function [ res ] = evaluate( t, pointsX, pointsY, k, x )
%evaluate evaluates function for a specific value
%   Detailed explanation goes here

    %calculates r
    r = -1;
    for i = 1 : (length(t) - 1)
        if t(i) <= x && t(i + 1) > x
            r = i;
            break;
        end
    end
    
    if r < 0
        for i = 1 : (length(t) - 1)
            if t(i) <= x && t(i + 1) >= x
                r = i;
                break;
            end
        end
    end

    res = evaluateRec(t, pointsX, pointsY, k + 1, x, r, r, k);
end

