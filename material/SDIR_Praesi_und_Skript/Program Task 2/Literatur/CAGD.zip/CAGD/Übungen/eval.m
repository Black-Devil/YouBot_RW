function [ res ] = eval( t, pointsX, pointsY, x )
%eval Evaluates the curve for a specific value
%   Detailed explanation goes here
    
    %calculates r
    r = -1;
    for i = 1 : (length(t) - 1)
        if t(i) <= x && t(i + 1) > x
            r = i;
            break;
        end
    end
    
    if r < 0
        for i = 1 : (length(t) - 1)
            if t(i) <= x && t(i + 1) >= x
                r = i;
                break;
            end
        end
    end
    
    res = evalRec(t, pointsX, pointsY, x, r, 3, 1);

end

