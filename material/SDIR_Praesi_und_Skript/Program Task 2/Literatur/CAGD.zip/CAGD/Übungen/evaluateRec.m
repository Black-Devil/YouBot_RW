function [ res ] = evaluateRec(t , pointsX, pointsY, k, x, r, i, j)
%avaluateRec recursive call of evaluate
%   Detailed explanation goes here
    if j == 1
        res = [pointsX(i), pointsY(i)];
    end
    
    if j > 1
        a = (x - t(i)) / (t(i + k - j) - t(i));
        res = (1 - a) * evaluateRec(t, pointsX, pointsY, k, x, r, i - 1, j - 1) + a * evaluateRec(t, pointsX, pointsY, k, x, r, i, j - 1);
    end
end

