function [ res ] = evalRec( t, pointsX, pointsY, x, r, level, j )
%evalRec recursive call of eval
%   Detailed explanation goes here
    k = 0;
    l = 0;
    
    if level <= 0
        %calculates indice (with respect to boundary conditions)
        switch j
            case 1
                if r-3 < 1
                    k = 1;
                else
                    k = r-3;
                end
            case 2
                if r-2 < 1
                    k = 1;
                else
                    k = r-2;
                end
            case 3
                if r-1 < 1
                    k = 1;
                else
                    k = r-1;
                end
            case 4
                if r+1 > length(pointsX)
                    k = length(pointsX);
                else
                    k = r+1;
                end
        end
        
        %calculates point for interpolation in higher recursive steps
        res = [pointsX(k), pointsY(k)];
    else
        %calculates interpolations for higher recursive steps
        if level == 3
            if r+1 > length(pointsX)
                k = length(pointsX);
            else
                k = r+1;
            end
            res = evalRec(t, pointsX, pointsY, x, r, 2, 1) * (t(k) - r) + evalRec(t, pointsX, pointsY, x, r, 2, 2) * (r - t(r-1+1));
        elseif level == 2
            if j == 1
                if r+1 > length(pointsX)
                    k = length(pointsX);
                else
                    k = r+1;
                end
                
                if r-2+1 < 1
                    l = 1;
                else
                    l = r-2+1;
                end
                res = evalRec(t,pointsX, pointsY, x, r, 1, 1) * (t(k) - r) + evalRec(t, pointsX, pointsY, x, r, 1, 2) * (r - t(l));
            else
                if r+2 > length(pointsX)
                    k = length(pointsX);
                else
                    k = r+2;
                end
                res = evalRec(t,pointsX, pointsY, x, r, 1, 2) * (t(k) - r) + evalRec(t, pointsX, pointsY, x, r, 1, 3) * (r - t(r-1+1));
            end
        else
            switch j
                case 1
                    if r+1 > length(pointsX)
                        k = length(pointsX);
                    else
                        k = r+1;
                    end
                    
                    if r-3+1 < 1
                        l = 1;
                    else
                        l = r-3+1;
                    end
                    res = evalRec(t,pointsX, pointsY, x, r, 0, 1) * (t(k) - r) + evalRec(t, pointsX, pointsY, x, r, 0, 2) * (r - t(l));
                case 2
                    if r+2 > length(pointsX)
                        k = length(pointsX);
                    else
                        k = r+2;
                    end
                    
                    if r-2+1 < 1
                        l = 1;
                    else
                        l = r-2+1;
                    end
                    res = evalRec(t,pointsX, pointsY, x, r, 0, 2) * (t(k) - r) + evalRec(t, pointsX, pointsY, x, r, 0, 3) * (r - t(l));
                case 3
                    if r+3 > length(pointsX)
                        k = length(pointsX);
                    else
                        k = r+3;
                    end
                    
                    res = evalRec(t,pointsX, pointsY, x, r, 0, 3) * (t(k) - r) + evalRec(t, pointsX, pointsY, x, r, 0, 4) * (r - t(r-1+1));
            end
        end
    end

end

